import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import ProductList from './pages/ProductList';
import ProductDetail from './pages/ProductDetail';
import './styles.css';  // Import your CSS file here

function App() {
  return (
    <Router>
      <div className="App bg-dark text-light"> {/* Apply dark theme and light text */}
        <Routes>
          <Route path="/" element={<ProductList />} />
          <Route path="/detail/:id" element={<ProductDetail />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
