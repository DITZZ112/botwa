import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';
import { Swiper, SwiperSlide } from 'swiper/react';
import 'swiper/css';

function ProductDetail() {
  const { id } = useParams();
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedImage, setSelectedImage] = useState('');

  useEffect(() => {
    axios.get(`http://localhost:5000/detail/${id}`)
      .then(response => {
        setProduct(response.data);  // Adjust based on API response
        setLoading(false);
      })
      .catch(error => {
        console.error('Error fetching product details!', error);
        setLoading(false);
      });
      
  }, [id]);

  const handleDownload = () => {
    // Update download count on the product
    axios.post(`http://localhost:5000/update-downloads/${id}`, { download: 1 })
      .then(response => {
        setProduct(prevProduct => ({
          ...prevProduct,
          download_count: response.data.download_count,
        }));
      })
      .catch(error => {
        console.error('Error updating download count!', error);
      });
  };

  const openModal = (image) => {
    setSelectedImage(image);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setSelectedImage('');
  };

  if (loading) {
    return (
      <div className="min-h-screen py-10 px-4 bg-gray-800 text-white">
        {/* Skeleton Loader for Banner */}
        <div className="w-full h-56 bg-gray-700 animate-pulse rounded-t-lg mb-4"></div>

        {/* Skeleton Loader for Product Info */}
        <div className="flex items-center gap-4 mb-4">
          <div className="w-20 h-20 bg-gray-700 rounded-full animate-pulse"></div>
          <div className="flex flex-col gap-2">
            <div className="w-32 h-6 bg-gray-700 animate-pulse"></div>
            <div className="w-48 h-4 bg-gray-600 animate-pulse"></div>
          </div>
        </div>

        {/* Skeleton Loader for Description */}
        <div className="w-full h-12 bg-gray-700 animate-pulse rounded-md mb-6"></div>

        {/* Skeleton Loader for Rating */}
        <div className="mt-8 flex items-center gap-2">
          <div className="w-24 h-6 bg-gray-700 animate-pulse rounded-md"></div>
        </div>

        {/* Skeleton Loader for Slider */}
        <div className="overflow-x-auto mt-6">
          <div className="flex gap-4">
            <div className="w-48 h-48 bg-gray-700 animate-pulse rounded-lg"></div>
            <div className="w-48 h-48 bg-gray-700 animate-pulse rounded-lg"></div>
            <div className="w-48 h-48 bg-gray-700 animate-pulse rounded-lg"></div>
          </div>
        </div>
      </div>
    );
  }

  if (!product) {
    return <div className="text-center py-10 text-white">Product not found</div>;
  }

  return (
    <div className="min-h-screen py-10 px-4 bg-gray-800 text-white">
      {/* Banner Image */}
      <img src={product.banner} alt="Banner" className="w-full h-56 object-cover rounded-t-lg mb-4" />
      
      {/* Product Info */}
      <div className="flex items-center gap-4">
        <img src={product.foto} alt={product.nama} className="w-20 h-20 rounded-full transform transition-all hover:scale-105" />
        <div>
          <h1 className="text-3xl font-bold">{product.nama}</h1>
          <p className="text-gray-400"><strong>Developer: </strong>{product.developer}</p>
        </div>
      </div>
      
      {/* Product Description */}
      <p className="mt-6 text-gray-400">{product.deskripsi}</p>

      <div className="flex items-center justify-between mt-6">
        {/* Download Button */}
        <a
          href={product.link_download}
          onClick={handleDownload}
          className="inline-block bg-blue-500 text-white px-6 py-2 rounded-full hover:bg-blue-600 transition"
        >
          Download
        </a>
        
        <p className="text-gray-400 mt-2">Jumlah Download: {product.download_count}</p>
      </div>

      {/* Rating Section */}
      <div className="mt-8 flex items-center gap-2">
        <p className="font-semibold">Rating: </p>
        <div className="flex text-yellow-400">
          {/* Full stars */}
          {Array.from({ length: Math.floor(product.rating) }).map((_, i) => (
            <svg key={i} xmlns="http://www.w3.org/2000/svg" className="w-6 h-6" fill="currentColor" viewBox="0 0 20 20" stroke="currentColor">
              <path d="M9.049 2.927a1 1 0 0 1 1.902 0l2.1 4.268 4.717.688a1 1 0 0 1 .554 1.707l-3.413 3.325.806 4.722a1 1 0 0 1-1.451 1.054l-4.242-2.227-4.243 2.227a1 1 0 0 1-1.451-1.054l.807-4.722-3.413-3.325a1 1 0 0 1 .554-1.707l4.718-.688 2.1-4.268z" />
            </svg>
          ))}
          
          {/* Half star (if the rating is a decimal) */}
          {product.rating % 1 !== 0 && (
            <svg xmlns="http://www.w3.org/2000/svg" className="w-6 h-6" fill="currentColor" viewBox="0 0 20 20" stroke="currentColor">
              <path d="M9.049 2.927a1 1 0 0 1 1.902 0l2.1 4.268 4.717.688a1 1 0 0 1 .554 1.707l-3.413 3.325.806 4.722a1 1 0 0 1-1.451 1.054l-4.242-2.227-4.243 2.227a1 1 0 0 1-1.451-1.054l.807-4.722-3.413-3.325a1 1 0 0 1 .554-1.707l4.718-.688 2.1-4.268z" />
            </svg>
          )}

          {/* Empty stars for remaining rating */}
          {Array.from({ length: 5 - Math.ceil(product.rating) }).map((_, i) => (
            <svg key={i} xmlns="http://www.w3.org/2000/svg" className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 20 20" stroke="currentColor">
              <path d="M9.049 2.927a1 1 0 0 1 1.902 0l2.1 4.268 4.717.688a1 1 0 0 1 .554 1.707l-3.413 3.325.806 4.722a1 1 0 0 1-1.451 1.054l-4.242-2.227-4.243 2.227a1 1 0 0 1-1.451-1.054l.807-4.722-3.413-3.325a1 1 0 0 1 .554-1.707l4.718-.688 2.1-4.268z" />
            </svg>
          ))}
        </div>
      </div>

      {/* Slider for Product Photos */}
      <div className="mt-8">
        <h2 className="text-xl font-semibold p-2">Foto Produk</h2>
        <Swiper
          spaceBetween={10}      // Space between each image
          slidesPerView={3}      // Show 3 images in a row
          navigation
          breakpoints={{
            640: { slidesPerView: 1 },  // For small screens, show 1 image
            768: { slidesPerView: 2 },  // For medium screens, show 2 images
            1024: { slidesPerView: 3 }, // For large screens, show 3 images
          }}
        >
          {product.foto_slider.map((image, index) => (
            <SwiperSlide key={index}>
              <div className="relative pb-[177.78%]">
                <img
                  src={image}
                  alt={`product-${index}`}
                  className="absolute top-0 left-0 w-full h-full object-cover rounded-lg cursor-pointer transform transition-transform duration-500 hover:scale-110"
                  onClick={() => openModal(image)}  // Open modal on image click
                />
              </div>
            </SwiperSlide>
          ))}
        </Swiper>
      </div>

      {/* Modal for Enlarged Image */}
      {isModalOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 opacity-0 animate-fadeIn"
          onClick={closeModal}
        >
          <div className="relative max-w-4xl max-h-full animate-zoomIn">
            <img
              src={selectedImage}
              alt="Enlarged Product"
              className="w-full h-auto object-contain rounded-lg"
            />
            <button
              className="absolute top-4 right-4 text-white text-2xl"
              onClick={closeModal}
            >
              &times;
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default ProductDetail;
