import React, { useEffect, useState } from "react";
import axios from "axios";
import Slider from "react-slick";
import { Link } from "react-router-dom";
import { FaDownload, FaThList } from "react-icons/fa"; // Ikon dari react-icons
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

function ProductList() {
  const [products, setProducts] = useState([]);
  const [sliderData, setSliderData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [categories, setCategories] = useState([]);
  const [loadingCategory, setLoadingCategory] = useState(false); // Status untuk loading kategori

  useEffect(() => {
    // Mengambil data produk
    axios
      .get("http://localhost:5000/")
      .then((response) => {
        setProducts(response.data);
        setLoading(false);

        const uniqueCategories = [...new Set(response.data.map((item) => item.kategori))];
        setCategories(uniqueCategories);
      })
      .catch((error) => {
        console.error("There was an error fetching the products!", error);
        setLoading(false);
      });

    // Mengambil data untuk slider
    axios
      .get("http://localhost:5000/web")
      .then((response) => {
        setSliderData(response.data[0].foto_slider); // Asumsi data yang diterima berada dalam array di dalam objek
      })
      .catch((error) => {
        console.error("There was an error fetching the slider data!", error);
      });
  }, []);

  const handleCategoryClick = (category) => {
    setLoadingCategory(true);
    setSelectedCategory(category);
    setTimeout(() => {
      setLoadingCategory(false); // Menghentikan loading setelah data selesai dimuat
    }, 1000); // Waktu loading simulasi (1 detik)
  };

  if (loading) {
  return (
    <div className="container bg-gray-800 mx-auto py-8 px-4 sm:px-6 lg:px-8">
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 sm:gap-6">
        {Array.from({ length: 8 }).map((_, index) => (
          <div key={index} className="animate-pulse bg-slate-900 rounded-lg overflow-hidden">
            {/* Image Placeholder */}
            <div className="h-40 sm:h-48 bg-gray-700"></div>
            <div className="p-4">
              {/* Title Placeholder */}
              <div className="h-4 bg-gray-700 rounded w-3/4 mb-2"></div>
              {/* Description Placeholder */}
              <div className="h-3 bg-gray-700 rounded w-1/2"></div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
 }


  const filteredProducts =
    selectedCategory === "all"
      ? products
      : products.filter((product) => product.kategori === selectedCategory);

  const carouselSettings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 3000,
    arrows: false, // Menghilangkan tombol navigasi
    responsive: [
      { breakpoint: 1024, settings: { slidesToShow: 1 } },
      { breakpoint: 768, settings: { slidesToShow: 1 } },
      { breakpoint: 480, settings: { slidesToShow: 1 } },
    ],
  };

  return (
    <div className="bg-slate-900 text-white min-h-screen">
      <div className="container mx-auto py-8 px-4 sm:px-6 lg:px-8">
        {/* Carousel */}
        <Slider {...carouselSettings} className="mb-10">
          {sliderData.map((foto, index) => (
            <div key={index} className="relative rounded-lg overflow-hidden shadow-lg hover:scale-105 transform transition duration-500">
              <img
                src={foto}
                alt={`Slide ${index + 1}`}
                className="w-full h-64 object-cover transition-all duration-500 ease-in-out"
              />
              <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
                <h2 className="text-3xl font-bold text-yellow-300 text-shadow-md">Gambar {index + 1}</h2>
              </div>
            </div>
          ))}
        </Slider>

        {/* Filter Categories */}
        <div className="flex flex-wrap gap-6 justify-center mb-8">
          <button
            onClick={() => handleCategoryClick("all")}
            className={`px-4 py-2 rounded-lg transition-all duration-300 ${
              selectedCategory === "all"
                ? "bg-blue-600 text-white shadow-md"
                : "bg-gray-700 text-gray-300 hover:bg-blue-600 hover:text-white"
            }`}
          >
            <FaThList className="inline-block mr-2" /> Semua Kategori
          </button>
          {categories.map((category, index) => (
            <div
              key={index}
              onClick={() => handleCategoryClick(category)}
              className={`px-4 py-2 rounded-lg transition-all duration-300 ${
                selectedCategory === category
                  ? "bg-blue-600 text-white shadow-md"
                  : "bg-gray-700 text-gray-300 hover:bg-blue-600 hover:text-white"
              }`}
            >
              <FaThList className="inline-block mr-2" /> {category}
            </div>
          ))}
        </div>

        {/* Tampilkan Placeholder jika kategori sedang loading */}
        {loadingCategory ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-6">
            {Array.from({ length: 8 }).map((_, index) => (
              <div key={index} className="animate-pulse bg-gray-800 rounded-lg overflow-hidden">
                <div className="h-40 sm:h-48 bg-gray-700"></div>
                <div className="p-4">
                  <div className="h-4 bg-gray-700 rounded w-3/4 mb-2"></div>
                  <div className="h-3 bg-gray-700 rounded w-1/2"></div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-6">
            {/* Product Grid */}
            {filteredProducts.map((product) => (
              <div
                key={product.id}
                className="bg-slate-800 rounded-lg overflow-hidden shadow-xl transform transition-transform border-2 border-white"
              >
                <Link to={`/detail/${product.id}`}>
                  <img
                    src={product.foto}
                    alt={product.nama}
                    className="h-40 sm:h-48 w-full object-cover transition-transform duration-300 transform hover:scale-105"
                  />
                  <div className="p-4">
                    <h3 className="text-lg font-semibold text-yellow-400 text-shadow-md">{product.nama}</h3>
                    <p className="text-sm text-gray-300">{product.kategori}</p>
                    <div className="flex justify-between items-center mt-2">
                      <p className="text-sm text-gray-400">{product.download_count} Downloads</p>
                      <div className="flex items-center space-x-2">
                        <FaDownload className="text-yellow-400" />
                      </div>
                    </div>
                  </div>
                </Link>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default ProductList;
